with med_group AS
(
SELECT '1547545' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1547546' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1547547' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1547550' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1547551' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1547553' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657744' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657745' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657746' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657747' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657748' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657749' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657750' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657751' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1094833' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1094834' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1094837' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1094838' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1161327' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1186646' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657004' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657005' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657006' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657007' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657012' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657013' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1597876' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1597877' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1597878' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1597881' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1597882' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1597884' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657189' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657190' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657191' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657192' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657195' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1657196' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1991412' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1991413' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792776' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792777' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792778' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792779' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792780' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792781' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792782' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792783' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792784' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1792785' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '2119695' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '2119696' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875534' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875539' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875540' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875541' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875542' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875543' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875544' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875545' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875546' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1875547' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919503' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919504' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919505' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919506' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919507' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919508' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919509' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919510' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919511' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919512' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919515' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '1919516' as med_code ,'RX' as med_code_type
UNION ALL 
SELECT '0003-2327-11' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0003-2328-22' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0006-3026-02' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0006-3029-02' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0003-3734-13' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0003-3772-11' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0003-3774-12' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '50242-917-01' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '50242-917-86' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0310-4500-12' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '0310-4611-50' as med_code ,'ND' as med_code_type
UNION ALL 
SELECT '44087-353-51' as med_code ,'ND' as med_code_type

)

, dx_group AS
(
 SELECT '714' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.9' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '135' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '136.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '245.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '277.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '277.30' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '277.39' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '279.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '279.41' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '279.49' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '283.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '284.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '286.53' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '287.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '287.31' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '287.32' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '289.81' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '321.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '333.91' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '340' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '341.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '341.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '348.39' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '357.81' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '358.00' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '358.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '358.30' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '359.71' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '360.11' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '362.18' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '363.21' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '364.00' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '364.01' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '364.02' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '364.03' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '364.04' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '364.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '370.52' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '372.39' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '373.34' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '377.30' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.00' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.01' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.02' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.03' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.05' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.06' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.07' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.09' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '379.51' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '386.00' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '420' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '422.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '422.91' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '425.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '443.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '446.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '446.21' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '446.29' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '446.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '446.5' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '446.7' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '447.6' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '516.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '516.30' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '516.31' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '530.13' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '555' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '555.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '555.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '555.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '555.9' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.5' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.6' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '556.9' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '567.82' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '571.42' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '571.6' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '580' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '580.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '580.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '580.81' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '580.9' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.81' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.89' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '582.9' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.6' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.7' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.81' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.89' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '583.9' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '616.51' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '686.01' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '694.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '694.5' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '694.6' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '694.60' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '694.61' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '694.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '695.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '695.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '696' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '696.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '696.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '696.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '697.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '701.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '704.01' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.4' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '710.8' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.20' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.21' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.22' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.23' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.24' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.25' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.26' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.27' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.28' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '711.29' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.30' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.31' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.32' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.33' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '714.81' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '719.3' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '720' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '720.0' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '720.2' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '721.6' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '725' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '729.1' as dx_code ,'09' as dx_code_type
UNION ALL 
SELECT '795.79' as dx_code ,'09' as dx_code_type



UNION ALL 
SELECT  'A01.09' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'A40' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'A41.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'A50.59' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B52.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.30' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.31' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.32' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.39' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.40' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.41' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.42' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.49' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B57.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B65.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B74' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'B78.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'C88.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'C90.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'C90.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D27.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D39.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D49.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D51.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D55' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D56' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D57' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D58' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D59' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D59.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D59.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D59.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D59.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D60' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D65' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.311' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.312' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.51' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.52' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.59' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.61' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D68.62' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D69.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D69.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D69.41' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D77' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D80.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D80.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.82' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.83' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.84' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.85' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.86' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.87' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D86.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D89.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D89.82' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'D89.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E05.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E06.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E06.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E09.21' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E09.22' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E09.29' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E11.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E27.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E31.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E75.21' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E78.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.82' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'E85.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G02' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G25.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G25.82' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G32.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G35' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G36.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G37.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G54.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G61.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G61.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G63' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G70.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G70.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G70.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G72.41' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G73.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G73.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G73.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G90.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G93.49' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G99.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'G99.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.12' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.121' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.122' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.123' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.124' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.125' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.126' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H01.129' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H10.51' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H10.511' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H10.512' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H10.513' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H10.519' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H10.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.001' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.002' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.003' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.009' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.011' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.012' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.013' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.019' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.021' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.022' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.023' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.029' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.031' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.032' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.033' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.039' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.041' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.042' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.043' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.049' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.091' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.092' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.093' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.099' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.101' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.102' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.103' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.109' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.111' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.112' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.113' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.119' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.121' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.122' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.123' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H15.129' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H16.05' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H16.32' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H16.321' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H16.322' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H16.323' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H16.329' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.011' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.012' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.013' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.019' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.021' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.022' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.023' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.029' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.031' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.032' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.033' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.039' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.041' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.042' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.043' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.049' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H20.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H30.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H30.20' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H30.21' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H30.22' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H30.23' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H35.06' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H35.061' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H35.062' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H35.063' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H35.069' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H42' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H44.131' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H44.132' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H44.133' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H44.139' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H46' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H46.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H49.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H51.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H55.01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H81.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H81.01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H81.02' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H81.03' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'H81.09' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I02' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I24.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I27.21' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I33' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I33.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I40.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I40.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I41' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I43' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I52' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I67.83' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I68.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I73.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I73.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I73.01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I77.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'I79.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'J84.10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'J84.111' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'J84.112' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'J93.12' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'J99' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K20.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.011' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.012' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.013' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.014' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.018' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.019' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.11' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.111' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.112' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.113' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.114' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.118' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.119' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.811' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.812' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.813' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.814' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.818' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.819' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.90' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.91' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.911' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.912' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.913' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.914' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.918' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K50.919' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.011' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.012' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.013' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.014' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.018' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.019' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.20' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.211' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.212' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.213' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.214' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.218' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.219' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.30' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.311' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.312' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.313' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.314' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.318' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.319' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.40' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.411' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.412' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.413' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.414' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.418' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.419' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.50' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.511' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.512' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.513' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.514' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.518' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.519' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.811' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.812' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.813' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.814' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.818' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.819' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.90' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.911' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.912' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.913' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.914' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.918' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K51.919' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K52' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K59.31' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K65.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K74.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K74.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K74.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K75.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K77' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'K90.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L10.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L12.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L12.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L12.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L12.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L12.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L13.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L13.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L14' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L30.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.50' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.51' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.52' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.53' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.54' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.59' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L40.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L41.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L43.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L52' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L63' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L63.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L63.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L63.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L63.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L63.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L66.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L88' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L90.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L93' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L93.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L93.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L93.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L94' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L94.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L94.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L94.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L94.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'L99' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M02.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M04.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M04.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M04.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.111' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.112' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.119' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.121' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.122' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.129' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.131' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.132' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.139' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.141' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.142' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.149' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.151' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.152' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.159' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.161' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.162' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.169' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.171' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.172' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.179' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.19' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.40' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.411' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.412' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.419' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.421' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.422' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.429' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.431' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.432' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.439' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.441' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.442' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.449' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.451' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.452' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.459' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.461' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.462' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.469' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.471' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.472' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.479' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.49' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.50' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.511' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.512' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.519' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.521' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.522' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.529' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.531' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.532' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.539' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.541' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.542' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.549' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.551' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.552' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.559' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.561' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.562' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.569' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.571' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.572' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.579' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.59' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.70' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.711' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.712' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.719' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.721' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.722' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.729' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.731' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.732' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.739' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.741' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.742' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.749' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.751' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.752' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.759' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.761' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.762' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.769' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.771' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.772' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.779' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.79' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.811' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.812' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.819' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.821' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.822' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.829' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.831' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.832' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.839' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.841' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.842' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.849' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.851' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.852' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.859' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.861' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.862' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.869' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.871' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.872' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.879' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M05.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.011' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.012' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.019' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.021' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.022' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.029' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.031' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.032' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.039' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.041' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.042' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.049' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.051' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.052' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.059' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.061' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.062' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.069' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.071' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.072' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.079' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.08' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.09' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.20' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.211' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.212' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.219' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.221' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.222' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.229' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.231' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.232' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.239' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.241' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.242' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.249' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.251' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.252' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.259' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.261' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.262' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.269' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.271' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.272' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.279' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.28' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.29' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.30' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.311' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.312' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.319' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.321' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.322' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.329' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.331' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.332' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.339' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.341' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.342' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.349' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.351' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.352' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.359' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.361' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.362' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.369' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.371' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.372' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.379' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.38' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.39' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.811' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.812' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.819' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.821' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.822' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.829' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.831' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.832' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.839' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.841' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.842' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.849' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.851' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.852' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.859' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.861' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.862' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.869' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.871' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.872' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.879' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.88' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M06.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.011' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.012' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.019' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.021' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.022' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.029' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.031' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.032' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.039' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.041' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.042' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.049' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.051' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.052' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.059' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.061' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.062' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.069' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.071' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.072' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.079' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.08' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.09' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.20' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.211' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.212' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.219' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.221' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.222' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.229' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.231' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.232' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.239' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.241' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.242' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.249' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.251' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.252' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.259' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.261' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.262' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.269' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.271' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.272' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.279' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.28' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.29' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.40' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.411' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.412' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.419' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.421' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.422' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.429' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.431' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.432' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.439' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.441' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.442' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.449' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.451' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.452' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.459' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.461' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.462' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.469' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.471' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.472' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.479' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.48' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.811' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.812' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.819' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.821' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.822' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.829' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.831' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.832' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.839' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.841' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.842' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.849' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.851' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.852' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.859' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.861' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.862' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.869' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.871' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.872' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.879' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.88' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.90' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.911' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.912' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.919' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.921' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.922' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.929' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.931' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.932' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.939' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.941' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.942' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.949' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.951' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.952' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.959' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.961' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.962' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.969' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.971' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.972' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.979' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.98' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M08.99' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M12.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M14.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M30' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M30.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M30.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M30.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.30' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.31' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M31.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.11' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.12' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.13' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.14' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.15' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.19' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M32.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.02' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.03' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.09' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.11' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.12' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.13' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.19' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.20' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.21' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.22' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.29' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.90' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.91' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.92' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.93' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M33.99' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.81' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.82' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.83' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M34.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.01' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.02' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.03' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.04' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.09' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M35.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M36' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M36.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M36.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M45.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M46.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.11' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.12' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.13' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.14' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.15' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.16' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.17' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.18' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.19' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M48.8X9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.80' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.811' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.812' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.819' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.821' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.822' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.829' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.831' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.832' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.839' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.841' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.842' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.849' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.851' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.852' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.859' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.861' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.862' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.869' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.871' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.872' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.879' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.88' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.89' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M60.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M61.10' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M79.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M79.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.31' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.311' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.312' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.319' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.32' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.321' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.322' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.329' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.33' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.331' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.332' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.339' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.341' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.342' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.349' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.35' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.351' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.352' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.359' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.36' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.361' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.362' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.369' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.37' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.371' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.372' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.379' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.38' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M86.39' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'M94.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N00.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N01.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N02.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N03.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N04.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N05.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N06.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.7' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N07.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N08' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N14.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N14.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N14.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N14.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N14.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N15.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N15.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N15.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N16' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N17.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N17.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N29' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N30.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N48.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N77.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.1' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.2' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.3' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.5' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N80.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'N90.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'O26.4' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'Q24.6' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'R76.0' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'R76.8' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'R76.9' as dx_code ,'10' as dx_code_type
UNION ALL 
SELECT  'Z11.6' as dx_code ,'10' as dx_code_type
)

, pat_meds as
(select sub.patid, min(sub.min_date) as first_med_date,sub.med_code,sub.med_code_type 
from
    (   
    select
    p.patid,g.med_code,g.med_code_type,
    min(coalesce(p.rx_start_date, p.rx_order_date)) as min_date
    from prescribing p
    join med_group g on 
        (cast(p.rxnorm_cui as varchar(25))= g.med_code and g.med_code_type = 'RX') or
        (p.raw_rx_ndc = g.med_code and g.med_code_type = 'ND')
    group by p.patid,g.med_code,g.med_code_type 
    union
    select
    d.patid,g.med_code,g.med_code_type,
    min(d.dispense_date) as min_date
    from dispensing d
    join med_group g on d.ndc = g.med_code and g.med_code_type = 'ND'
    group by d.patid,g.med_code,g.med_code_type 
	union
	select
    p.patid, g.med_code, g.med_code_type,
    min(p.px_date) as med_date
    from procedures p
    join med_group g on p.px = g.med_code and p.px_type = g.med_code_type
	group by p.patid, g.med_code, g.med_code_type
	union
    select
    ma.patid,g.med_code,g.med_code_type, 
    min(ma.medadmin_start_date) as min_date
    from med_admin ma
    join med_group g on ma.medadmin_code = g.med_code and ma.medadmin_type = g.med_code_type
    group by ma.patid,g.med_code,g.med_code_type
) sub
group by sub.patid,sub.med_code,sub.med_code_type 
)
, pat_cum as (
select
pat_meds.patid,
pat_meds.med_code,pat_meds.med_code_type,dxg.dx_code,dxg.dx_code_type
from pat_meds
join diagnosis diag on pat_meds.patid = diag.patid
 --   and diag.admit_date > pat_meds.first_med_date -183
 --   and diag.admit_date < pat_meds.first_med_date
	AND DATEDIFF(day, pat_meds.first_med_date, diag.admit_date) > 0
    AND DATEDIFF(day, pat_meds.first_med_date, diag.admit_date) <= 183
join dx_group dxg on diag.dx = dxg.dx_code and diag.dx_type = dxg.dx_code_type
union 
select
pat_meds.patid, 
pat_meds.med_code,pat_meds.med_code_type,dxg.dx_code,dxg.dx_code_type
from pat_meds
join condition c on pat_meds.patid = c.patid
 --   and c.report_date > pat_meds.first_med_date -183
 --   and c.report_date < pat_meds.first_med_date
        AND DATEDIFF(day, pat_meds.first_med_date, c.report_date) > 0
        AND DATEDIFF(day, pat_meds.first_med_date, c.report_date) <= 183
join dx_group dxg on c.condition = dxg.dx_code and c.condition_type = dxg.dx_code_type
where c.condition_source = 'HC' 
)
, patient_data as (
  SELECT p.PATID,
p.SEX AS GENDER, p.RACE, p.HISPANIC AS ETHNICITY, p1.DX_CODE as DIAGNOSIS,p1.Med_Code AS DRUG, p1.dx_code_type,p1.med_code_type
FROM DEMOGRAPHIC p 
JOIN pat_cum p1 ON p.PATID=p1.PATID 
--WHERE 
--TRUNC(MONTHS_BETWEEN(SYSDATE, p.BIRTH_DATE)/12) BETWEEN 1 AND 89 
--DATEDIFF(YY, p.BIRTH_DATE,GETDATE()) BETWEEN 1 AND 89 
)
SELECT c.* FROM CONDITION c JOIN PATIENT_DATA p ON p.PATID=c.PATID AND c.CONDITION = p.DIAGNOSIS AND c.CONDITION_TYPE=p.dx_code_type